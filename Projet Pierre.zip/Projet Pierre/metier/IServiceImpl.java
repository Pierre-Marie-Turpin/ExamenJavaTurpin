package metier;

import models.Service;
import models.Employe;
import models.Journalier;
import models.Embauche;



/**
 *
 * @author Pierre Turpin
 */
public class IServiceImpl implements IService{
    @Override
    public Service add(int id, String libelle) { 
         private static List<Service> ListService = Arrays.asList(
        new Service("1","informatique")
    );  
    }

    @Override
    public Service affiche() { 
        for(Service elem: ListService)
       {
       	 System.out.println (elem);
       }  
    }

    @Override
    public  compare(int id) {   
    }

    @Override
    public Service compare(String libelle) {   
    }

    @Override
    public Employe addEmp() {
        private static List<Employe> ListEmploye = Arrays.asList(
        new Employe("1","Pierre Marie Turpin")
    );
    }

    @Override
    public Embauche afficheEmbauche() {
        ArrayList<Embauche> array_L=new ArrayList<Embauche>();
         for(Embauche elem: Employe)
       {
       	 array_L.add(Embauche);
       }

       for(Embauche elem: array_L)
       {
       	 System.out.println (elem);
       }  
    }

     @Override
    public Journalier afficheJournalier() {
        ArrayList<Journalier> array_L=new ArrayList<Journalier>();
         for(Journalier elem: Employe)
       {
       	 array_L.add(Journalier);
       }

       for(Journalier elem: array_L)
       {
       	 System.out.println (elem);
       }  
    }



    





    