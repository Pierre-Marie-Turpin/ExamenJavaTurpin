package metier;

import models.Beans.Service;
import models.Beans.Employe;



/**
 *
 * @author Pierre Turpin
 */
public interface IService {
    public Service add(int id, String libelle);
    public Service affiche();
    public Service compare(int id);
    public Service compare(String libelle);
    public Employe addEmp();
    public Employe afficheEmbauche();
    public Employe afficheJournalier();
}